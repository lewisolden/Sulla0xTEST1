import React from "react";

function Dashboard() {
  return <h1>Dashboard Page</h1>;
}

export default Dashboard;
