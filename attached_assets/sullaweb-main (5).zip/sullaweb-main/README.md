# Sulla - Cryptocurrency Education Platform

## Project Overview
Sulla is an educational platform dedicated to teaching cryptocurrency and blockchain technologies.

## Technologies Used
- React
- Tailwind CSS
- React Router
- Vercel Deployment

## Getting Started

### Prerequisites
- Node.js (v14 or later)
- npm or yarn

### Installation
1. Clone the repository
2. Install dependencies:
